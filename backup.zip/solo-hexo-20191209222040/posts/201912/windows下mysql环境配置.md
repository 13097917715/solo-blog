title: 【windows下mysql环境配置】
date: '2019-12-08 20:16:16'
updated: '2019-12-08 20:17:21'
tags: [mysql, 教程]
permalink: /articles/2019/12/08/1575807376622.html
---
![](https://img.hacpai.com/bing/20180627.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

今天带来的是一种超级简单的在windows下快速配置mysql环境的方法。
此方法只适用学习、测试，对数据库要求不是很高的同学适用，并不适用项目的开发。如果要专业适用数据库的，请前往官方查看说明文档。
# 1.准备工作
首先你要下载好你要是用的mysql数据库的压缩包。
[官网地址](https://dev.mysql.com/downloads/mysql/)
直接下载你需要的版本
![image.png](https://img.hacpai.com/file/2019/12/image-7201d9b1.png)
# 2.路径配置
下载解压完成后，会出现想这样的一个带版本号的文件夹
![image.png](https://img.hacpai.com/file/2019/12/image-cd94ad44.png)

然后我们在这个文件夹里，找一个叫bin的目录，在里面找到mysqld这个文件。
![image.png](https://img.hacpai.com/file/2019/12/image-6558e7aa.png)

然后复制这个文件的路径，到系统环境的path里添加上去
像我的这样添加上去就可以了
![image.png](https://img.hacpai.com/file/2019/12/image-3795190e.png)
保存退出！
# 3.启动服务
打开小黑框
>mysqld install
>net start mysql
>mysql -p root -p
第一次进入应该是默认免密的，这样你应该看到就是这样的
![image.png](https://img.hacpai.com/file/2019/12/image-3497f84d.png)
这样就说明你的mysql服务安装成功了！
# 4.mysql开机启动
虽然这样已经安装好了，但是依然不能做到随连随用，因为已关机，我们的mysql服务就会关掉，这样太麻烦了，每次开机还要打开一次，所以我建把mysql服务做成一个开机服务项，只要开机就能连上，做到真正的随连随用！
进入计算机服务项中（我的电脑 (右键)---->管理---->服务和应用程序---->查看有没有MySQL服务项），发现没有 MySQL 服务。
再次打开小黑框
>mysqld.exe install
此时再查看计算机服务项,就有MySQL服务了
![image.png](https://img.hacpai.com/file/2019/12/image-64cf7a2a.png)
再将这个服务设为开机启动，这样我们的mysql服务就能跟随我们的windows一起启动了！
只要一开机，就能愉快的连上我们的服务器了！



以上教程纯属个人经验总结，如若有错，欢迎指正！
如果你觉得这篇文章对你有用，请帮忙点亮爱心，谢谢!
