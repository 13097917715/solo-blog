title: 【python学生信息管理系统】
date: '2019-12-07 22:08:52'
updated: '2019-12-08 20:43:36'
tags: [python]
permalink: /articles/2019/12/07/1575727732738.html
---
![](https://img.hacpai.com/bing/20171217.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 1. 简述
本文讲述的是用python语言写一个简单的学生信息管理系统，系统包含学生信息的增删查改功。同时使用了mysql5.7.14来存储数据。

# 2.准备工作
首先，先搭建好自己的mysql数据库，不懂怎么搭建的可以参考百度，这里就不详细讲了。
百度的安装放发太麻烦了，这个教程可以教你们怎样快速在windows下搭建mysql环境。
http://chengge.club/articles/2019/12/08/1575807376622.html
继续我们的话题我的数据库是本地的所以链接名`host='127.0.0.1'`，账户`user='root'`，密码`password='666666'`。
同时，我们的python也要导入对应mysql的包
`pymysql`，具体如何导包可以百度，用pycharm的话导包也是非常方便的。
# 3.代码部分
## 1.添加学生信息
  ```
def add_new_student():
    '''增添新学生'''
    sno = input('请输入学号：')
    name = input('请输入姓名：')
    sex = input('请输入性别：')
    age = input('请输入年龄：')
    cin = 'insert into student(sno,name,sex,age) values(%s,%s,%s,%s);'
    try:
        re1 = cursor.execute(cin, (sno, name, sex, age))
        conn.commit()
        print(name, "添加成功！")
    except Exception:
        print("学号已存在！")
        conn.rollback()
        return 0
```
## 2.删除学生信息
```
def del_student():
    '''删除学生'''
    sno = input('请输入要删除的学生的学号：')
    del_student = "delete from student where sno="+sno
    try:
        re1 = cursor.execute(del_student)
        if re1 == 1:
            print("删除成功")
        else:
            print("删除失败")
        #res1 = cursor.fetchmany(re1)
        #print('学号：', res1[0][0], ' 姓名：', res1[0][1], ' 性别：', res1[0][2], ' 年龄：', res1[0][3])
    except Exception:
        print("查无此人，删除失败！！")
        conn.rollback()
        return 0
```
## 3.修改学生信息
```
def gai_student():
    '''修改一个学生'''
    sno = input('请输入要修改的学生的学号：')
    new_name = input('请输入新姓名：')
    new_sex = input('请输入新性别：')
    new_age = input('请输入新年龄：')
    del_student = "delete from student where sno=" + sno
    cin = 'insert into student(sno,name,sex,age) values(%s,%s,%s,%s);'
    try:
        re1 = cursor.execute(del_student)
        re1 = cursor.execute(cin, (sno, new_name, new_sex, new_age))
        print("修改成功")
        # res1 = cursor.fetchmany(re1)
        # print('学号：', res1[0][0], ' 姓名：', res1[0][1], ' 性别：', res1[0][2], ' 年龄：', res1[0][3])
    except Exception:
        print("查无此人，修改失败！！")
        conn.rollback()
        return 0
```
这里的修改我是用删除后重新添加的方式实现修改的。
## 4.查询学生信息
```
def find_student():
    '''查找学生'''
    find = input('请输入要查询的学号：')
    sele_sno = 'select * from student where sno='+find
    sele_name = 'select * from student where name=' + find
    try:
        re1 = cursor.execute(sele_sno)
        #print(re1)
        res1 = cursor.fetchmany(re1)
        print('学号：', res1[0][0], ' 姓名：', res1[0][1], ' 性别：', res1[0][2], ' 年龄：', res1[0][3])
    except Exception:
        print("查询结果为空！")
        conn.rollback()
        return 0
```
## 5.查看全部学生的信息
```
def look_student():
    '''总览学生'''
    sele = 'select * from student'
    re1 = cursor.execute(sele)
    res1 = cursor.fetchmany(re1)
    i = 0
    for i in range(len(res1)):
        print('学号：', res1[i][0], '\t姓名：', res1[i][1], '\t性别：', res1[i][2], '\t年龄：', res1[i][3])
```
## 6.提示
```
def print_tips():
    '''打印功能提示'''
    print('=' * 30)
    print('   >>系统<<')
    print('1.添加')
    print('2.删除。')
    print('3.修改')
    print('4.查询')
    print('5.查看。')
    print('6.退出系统')
    print('=' * 30)

def main():
    while 1:
        print_tips()
        num = input('请输入你要选择的功能序号：')
        if num == '1':
            add_new_student()
        elif num == '2':
            del_student()
        elif num == '3':
            gai_student()
        elif num == '4':
            find_student()
        elif num == '5':
            look_student()
        elif num == '6':
            break
        else:
            print('不要皮了，请按提示输入！')
```
## 7.main
```
import pymysq
conn = pymysql.connect(host='127.0.0.1', user='root', password='666666', database='yang', charset='utf8')
cursor = conn.cursor()

if __name__ == '__main__':
    main()
```
# 4.总结
该系统逻辑简单明了，适合新手入门pytho学习，希望这篇文章能对你有所帮助！
