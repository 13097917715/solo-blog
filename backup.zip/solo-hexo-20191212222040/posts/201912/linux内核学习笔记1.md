title: 【linux内核学习笔记1】
date: '2019-12-10 09:27:52'
updated: '2019-12-10 09:27:52'
tags: [嵌入式]
permalink: /articles/2019/12/10/1575941272613.html
---

# 1.交叉开发模式
ubantu（开发环境）          <---交叉编译--->            开发板（运行环境）

arm-linux-gcc：交叉工具链

# 2.操作系统启动流程
	1.上点
	2.bootloder（u-boot.bin），加载内核
	3.rootfs：根文件系统，文件夹的集合（bin、sbin、etc、lib）
	4.


# 3.linux驱动开发环境
1.ubantu中配置编译环境
	设置交叉工具链
		解压gcc到指定目录
		设置环境变量
		vi /etc/profile    添加gcc的目录
		更新脚本：source /etc/profile
		
2.运行开发板
	开发板存储介质：DDR，emmc
	emmc：uboot.bin\内核\rootfs
	从emmc加载.....到neicun
挂在根文件系统
	通过tftb启动内核
	将uimage和dtb文件放入到ubantu中/tftpbooot
	在开发板中设置uboot参数，使其能够去加载内核
	
	set ipaddr 192.168.170.**
	set serverip 192.168.170.160
	set boot tftp 0x41000000 uimage\; tftp 0x42000000  exynos4421.dtb \; bootm 0x4100000000 -  0x42000000
		save
3.通过nfs去挂载一个roofs
	1.需要一个跟文件系统目录---rootfs。tar.gz，需要解压到ubantu
	sudo tar -xvf rootfs.tar.gz -C /opt/4412/
	2.配置nfs服务器（需要安装），让/opt/4412/rootfs可以被挂载

