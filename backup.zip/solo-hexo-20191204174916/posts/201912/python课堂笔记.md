title: 【python课堂笔记】
date: '2019-12-02 17:34:37'
updated: '2019-12-03 20:50:15'
tags: [python]
permalink: /articles/2019/12/02/1575279277084.html
---
驼峰式命名  几个单词组成，每个单词头大写

标识符：用下划线分割

如果要在计算中表示1.2*10的5次方:1.2E5

00001100>>2    右移两位   00000011

bin(20)=0b10100 		bin制表示求二进制

type()用来求变量类型

or和and的区别：
**a=1，b=2  (a or b)=1
a=1，b=2  (a and b)=1**

##### python中的多行语句可以使用反斜杠实现？？

python的成员运算符用于判断指定序列中是否包含某个值

幂运算：**（5**6表示5的6次方）
a,b=b,a(a,b互换)

python不支持char型数据

continue   跳出本次循环，开始下一次循环

pass 代表空语句，让结构更完整

python是没有switch-case语句的






