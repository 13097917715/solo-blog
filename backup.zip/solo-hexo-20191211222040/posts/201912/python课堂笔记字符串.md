title: 【python课堂笔记--字符串】
date: '2019-12-10 19:46:35'
updated: '2019-12-11 08:57:20'
tags: [python]
permalink: /articles/2019/12/10/1575978394942.html
---
# 转义字符
1.对于单引号或者双引号这些特殊的符号，我们可以对他们进行转义。例如，对字符串中的单引号进行转义:
```  
  >>>'let\'s go! go'

"let's go! go"
```
2.
	转义字符 |            代表含义
       \\(行尾)|   反斜杠符号
       \\\\| 反斜杠符号
       \\"|双引号
	\\n|换行
       \\b|退格
	\\t|横向制表符
# 输入输出
```  
name=input("请输入用户名")  
print("大家好，我叫%s"%name)

>>>小明明
大家好，我叫小明明
```
1.常见的格式化符号
%s：通过str()字符串转换来的格式化
%d：有符号十进制整数
%f：浮点实数

2.字符串的存储方式
字符串中的每个字符都对应一个下标，下标编号是从0开始的。
name = yanghai
name[1]：a
name[3]:  g

3.什么是切片
	切片的语法格式如下所示：
	[起始:结束:步长]
	name[1:5:1]:angha
	name[1:5:2]:aga
	name[2:]:nghai

4.字符串内建函数
**find函数：检测字符串是否包括子字符串**
str.find(str, beg=0, end=len(string))
参数如下：
str -- 指定检索的字符串。
beg -- 开始索引，默认为0。
end -- 结束索引，默认为字符串的长度。
**index函数：检测字符串是否包括子字符串**
str.index(str, beg=0, end=len(string))
参数如下：
str -- 指定检索的字符串。
beg -- 开始索引，默认为0。
end -- 结束索引，默认为字符串的长度。
**count函数：统计字符串中某个字符的个数**
str.count(sub, start= 0, end=len(string))
参数如下：
sub -- 搜索的子字符串。
start --  字符串开始搜索的位置。
end --  字符串中结束搜索的位置。
**replace函数：将旧字符串替换为新字符串**
str.replace(old, new[, max])
old --  将被替换的字符串。
new --  新字符串，用于替换old字符串。
max --  可选字符串，替换不超过mac次。
**splite函数：通过指定分隔符对字符串进行切片**
str.split(str="", num=string.count(str))
str.split(str="", num=string.count(str))
**startswith：检查字符串是否以制定子串开头**
str.startswith(str, beg=0,end=len(string))
str -- 检测的字符串。
strbeg -- 可选参数用于设置字符串检测的起始位置。
strend -- 可选参数用于设置字符串检测的结束位置。
**endswith：检查字符串是否以制定子串结尾**
str.endswith(suffix[, start[, end]])
suffix -- 该参数可以是一个字符串或者是一个元素。
start -- 字符串中的开始位置。
end -- 字符串中的结束位置。
**upper：将小写字母转为大写字母**
str.upper()
mystr = 'hello world itheima and itheimaApp'
newStr = mystr.upper()
**ljust：左对齐，使用空格填充至指定长度的新字符串**
str.ljust(width[, fillchar])
width -- 指定字符串长度。
fillchar -- 填充字符，默认为空格。
**rjust：右对齐，使用空格填充至指定长度的新字符串**  
str.rjust(width[, fillchar])  
width -- 指定字符串长度。  
fillchar -- 填充字符，默认为空格。
*lstrip：截掉字符串左边的空格或指定字符（rstrip与之效果相反）**
str.lstrip([chars])
chars --指定删除的字符。
**strip：截掉字符串左右边的空格或指定字符**
str.strip([chars])
chars --移除字符串头尾指定的字符。
**capitalize：第一个字符大写，其他字符小写**
str.capitalize()
**title：所有单词首字母大写，其余字母消息**
str.title()
