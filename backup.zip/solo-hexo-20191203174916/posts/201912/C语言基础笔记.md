title: 【C语言基础笔记】
date: '2019-12-01 20:44:43'
updated: '2019-12-02 17:35:21'
tags: [c语言]
permalink: /articles/2019/12/01/1575204283793.html
---
## c语言数据类型补充
*头文件:#include<stdio.h>*



## 整形
int a; //一般情况下是4个字节
long int a; //long  4/8bit（一般是系统自长的两倍）
long long int a; //long long 4/8bit

short int a；  //short  2bit

## 字符型
//所谓字符：本质就是单字节的整形
char c1 = 'a';
char c2 = 97; //97是‘a’的ASCLL码
取值范围：0--255/-128--127

## 浮点型
//浮点数：表示小数
fioat f1 = 1.123;			//4bytes
double f2 = 2.234;	  	//8bytes
long double f3 = 3.456;	//16bytes
//查看字符的的changdu
printf("float:%d\n",sizeof(float));
printf("double:%d\n",sizeof(double));
printf("long double :%d\n",sizeof(flong double));


## 布尔型
//布尔型：真、假
*头文件:#include<stdbool.h>*

//真：非0
//假：0
bool flag;
**//真**
fiag = true; 
fiag = 1;
fiag = 1.1;
fiag = 0.1;
fiag = -0.5;

**//假**
fiag = false;
fiag = 0;

## void
//void只能用来修饰指针
~~//void a;	//非法的~~
void *p;		//定义了一个目标未确定指针


***//长度固定、移植的数据类型（嵌入式行规）***
int32_t x;		//不管在哪里，x都是32位
int16_t y;		//不管在哪里，y都是16位
int8_t z;		//不管在哪里，z都是8位










